function greet(name,time){

    if(name == "Count Dooku"){
        console.log("I'm coming for you, Dooku!");
    }
    else {

   

    console.log("good day " + name);
    console.log("it is " + time);
}
}
greet("Count Dooku","9PM");