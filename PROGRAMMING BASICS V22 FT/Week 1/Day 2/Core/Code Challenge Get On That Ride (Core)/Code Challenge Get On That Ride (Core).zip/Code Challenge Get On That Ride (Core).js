var height = 44; //register rider height
var age =9.5; //register rider age
// var isTallEnough;//test if rider height is superior 42 inches
// var isOldEnough; //test if rider age is superior to 10
// var canRide; //test if someone can ride

// if ( height>=42)
//     console.log("Get on that ride, kiddo!");
//     else console.log("Sorry kiddo. Maybe next year.");

// if ( height>=42 && age >= 10)
//     console.log("Get on that ride, kiddo!");
//     else console.log("Sorry kiddo. Maybe next year.");

if ( height>=42 || age >= 10)
    console.log("Get on that ride, kiddo!");
    else console.log("Sorry kiddo. Maybe next year.");