// counter for likes
var likeCount = 0;
// declaration of a function
function increaseLikes() {
    // account for every like registered
    likeCount = likeCount + 1;
}
