var height; //register rider height
var age; //register rider age
var isTallEnough;//test if rider height is superior 42 inches
var isOldEnough; //test if rider age is superior to 10
var canRide; //test if someone can ride
