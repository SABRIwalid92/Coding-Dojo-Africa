//Level 1
//activity 1
var x=5;
console.log(x); //5

//Level 1
//activity 2
var x=3;
x=x+1.
console.log(x); //4

//Level 1
//activity 3
var x=3;
x=x+2;
console.log(x+2);//7
console.log(x);//5

//Level 1
//activity 4
var x=3;
x=x*x;
console.log(x);//9
console.log(x*2);//18

//Level 1
//activity 5
var x=2;
var y=5;
var z= x+y;
console.log(z);//7
